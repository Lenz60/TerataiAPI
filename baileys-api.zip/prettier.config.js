module.exports = {
	printWidth: 100,
	tabWidth: 4,
	useTabs: true,
	endOfLine: "lf",
	trailingComma: "all",
	semi: true,
	singleQuote: false,
};
