export enum LogLevel {
	ERROR = "error",
	WARN = "warn",
	DEBUG = "debug",
	INFO = "info",
	FATAL = "fatal",
	TRACE = "trace",
}
